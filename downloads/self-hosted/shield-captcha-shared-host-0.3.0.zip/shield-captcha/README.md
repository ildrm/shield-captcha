# Shield CAPTCHA

A Laravel 13 and Filament 5 application that issues bounded proof-of-work challenges, consumes one-time CAPTCHA tokens, and assesses SMS requests before they are sent. It runs on PHP and an InnoDB database with cron. The repository is a working core checkpoint. See [implementation status](IMPLEMENTATION_STATUS.md) for the release gates and the remaining product scope.

## Run locally

1. Create a fresh MySQL or MariaDB database and an account with access to that database. Copy `.env.example` to `.env` and enter the local database settings.
2. Install dependencies and initialize the service.

   ```sh
   composer install --no-plugins --no-scripts
   php artisan package:discover
   php artisan key:generate
   php artisan migrate
   php artisan filament:assets
   php artisan shield:preflight
   php artisan serve --host=127.0.0.1 --no-reload
   ```

3. Open `http://127.0.0.1:8000` and use `/customer/register`. Configure a local mail catcher with SMTP to receive the signed email verification link. The default array mailer is suitable for tests. Provision a dedicated operator with `php artisan shield:operator operator@example.test`. Sign in at `/admin/login` and enroll an authenticator.
4. Create an organization, then a sandbox site with the exact consumer origin and the action `contact`. Issue a verification key, enter your current password, and save the displayed secret in your backend configuration.

The app serves the quick start under `/docs`, the browser-only sandbox preview under `/playground`, the API contract at `/api-reference`, the release catalog with SHA-256 checksums at `/downloads`, and health checks under `/health`.

## Test the real integration

Register `http://127.0.0.1:8001` as a sandbox origin. Run the consumer on a second local port, providing the public site key and verification secret from your local process environment or secret manager.

```sh
export SHIELD_API_ORIGIN=http://127.0.0.1:8000
export SHIELD_CONSUMER_ORIGIN=http://127.0.0.1:8001
# Set SHIELD_SITE_KEY and SHIELD_VERIFY_SECRET in the shell without saving them to source.
php -S 127.0.0.1:8001 -t examples/php-consumer
```

Complete the widget and submit the form. The backend checks the newly consumed token and its exact expected context before rendering an accepted result. The example sends no message or other external side effect.

Run `composer test` for the lightweight suite. The InnoDB race test runs when you use an isolated local test database named `shield_test` (or `shield_test_*`) and PHP has `pcntl`.

```sh
DB_CONNECTION=mysql DB_HOST=127.0.0.1 DB_DATABASE=shield_test \
  DB_USERNAME=shield_test php vendor/bin/phpunit --no-progress
```

Use `DB_SOCKET` for Unix socket authentication if needed. Keep the test database and credentials separate from any deployed instance.

See [shared-host deployment](DEPLOYMENT.md), the [security model](SECURITY_MODEL.md), and the [original product requirements](docs/requirements/product-specification.md). The [revised implementation prompt](IMPLEMENTATION_PROMPT.md) defines delivery order and local resource limits.

Configure Stripe and ZarinPal checkout or Twilio and Kavenegar OTP delivery in [provider setup](docs/providers.md). Choose active providers in the operator panel.
