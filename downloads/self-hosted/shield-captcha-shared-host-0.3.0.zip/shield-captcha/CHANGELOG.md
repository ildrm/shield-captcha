# Changelog

## 0.3.0

- Stripe Checkout and signed payment webhooks alongside ZarinPal.
- Twilio OTP messaging alongside Kavenegar with the existing site sending scope.
- Audited operator provider settings supporting multiple checkout gateways and a single SMS provider.

## 0.2.0

- ZarinPal hosted checkout, fixed renewal terms, and paid verification allowances.
- Kavenegar template OTP delivery with per-site provisioning and a dedicated sending credential.
- Invoice reconciliation and tenant delivery history.
- Security refresh of locked Composer packages with a clean advisory check and an in-place upgrade rehearsal.

## 0.1.0

- Laravel and Filament core with organization-scoped customer and separate operator panels.
- Browser proof of work, one-time server verification, destination-based SMS assessment and bounded retention.
- Public English/Persian docs, sandbox widget preview, PHP consumer sample, and release downloads.
