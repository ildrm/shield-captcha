# Requirements traceability

The identifiers and complete acceptance conditions are preserved in the [product specification](docs/requirements/product-specification.md). Verified rows cover the listed behavior. Partial rows record implemented behavior and the remaining criteria. Pending rows await a full implementation.

| Requirement | State | Evidence or next dependency |
| --- | --- | --- |
| PROD-01, CAP-01–02, CAP-08–09 | Partial | `app/Shield/Captcha.php`, `routes/api.php`, widget assets, feature/replay tests and two-origin browser journey. Pilot SHA-256 provider needs independent assessment, theming and broader client coverage. |
| CAP-03–07 | Pending | Invisible, adaptive, slider/puzzle, image and accessibility alternatives. Baseline widget handles keyboard and spoken status. |
| PROD-02, ABUSE-01 | Partial | `/api/v1/sms/assess` and `/api/v1/sms/send`, administrator-selected Kavenegar or Twilio delivery, cooldown and velocity checks, idempotency and redacted history. Reporting, campaign savings and provider delivery callbacks remain. |
| PROD-03, ABUSE-02 | Pending | Account Shield and login/signup/recovery assessment. |
| PROD-04, ABUSE-03 | Pending | Bot and anti-spam policies. |
| PROD-05, ABUSE-04 | Pending | General-purpose assessment, endpoint quotas and customer API middleware. |
| PROD-06, ABUSE-05 | Pending | Fraud policies and reports for checkout, promotions and registration. |
| PROD-07, PROD-08, ABUSE-06 | Pending | Integrated scraper policies and verified automation/agents. Full coverage needs an optional gateway. |
| PROD-09, DOC-01–02, SDK-01 | Partial | `/docs/v1`, `/playground`, JavaScript/TypeScript and PHP packages, PHP consumer and OpenAPI/Postman. Remaining docs search, feature reference, migration, Laravel/Node/React/Vue/Next.js, Python/Go/Java/.NET/Ruby/Rust and mobile targets. |
| PROD-10 | Partial | Shared hosting ZIP, organization boundaries, basic roles and audit. Advanced entitlements, team workflows, policy, SSO, SLA and enterprise support remain. |
| Website §3 | Partial | Localized homepage, quick start, playground, releases, security and real readiness status in `resources/views/site`. Additional products/solutions, pricing, editorial/legal pages, search and metadata remain. |
| IAM-01 | Partial | Registration, email verification, login, password flows, TOTP and recovery baseline. Central session controls, real SMTP and complete localization remain. |
| IAM-02 | Partial | Organization-based Filament access, strict site origin, production DNS TXT, site policies and cross-tenant tests. Invitations, ownership transfer and wider roles remain. |
| IAM-03 | Partial | Scoped verification/assessment keys, digest storage, one-time password-confirmed reveal, revocation/rotation and tests. Expiry, last-used and management scope remain. |
| RISK-01 | Partial | Fixed thresholds and coarse assessment outcome. No calibrated scoring or editable rule pipeline. |
| RISK-02–03 | Pending | Shadow policies, feedback, versioning, reputation and model integration. |
| API-01–02 | Partial | Active widget, challenge, solve, verification, SMS assessment/delivery, liveness/readiness and OpenAPI. Other product, management and feedback APIs remain. |
| API-03 | Pending | Management credentials, signed webhooks and delivery diagnostics. |
| CUST-01–04 | Partial | Customer tenant/site onboarding, overview counts, exact origin/actions, DNS and key actions. Guided checklist and advanced filters/expiry remain. |
| CUST-05–06 | Pending | CAPTCHA designer and rule editor. |
| CUST-07–09 | Partial | Real per-tenant counts and SMS history; deeper analytics, reports, logs and configurable policy remain. |
| CUST-10–11 | Pending | Product-specific control panels, alerts and webhook deliveries. |
| CUST-12 | Partial | Catalog, site actions and quick start; automatic health and migration checklist remain. |
| CUST-13 | Partial | Membership-based policies with audit evidence; invite and role lifecycle UI and export remain. |
| CUST-14 | Partial | Customer choice among selected payment gateways, hosted fixed-term checkout, invoice history and quota display. Expanded plan management and invoice notifications remain. |
| CUST-15 | Pending | Expanded settings, privacy and support workflows. |
| ADMIN-01–03 | Partial | `/admin` dedicated guard, required TOTP, real counts and audit-backed organization suspension. Full operational and abuse workflows remain. |
| ADMIN-04 | Partial | Runtime checkout-gateway and SMS selection with operator MFA, password confirmation and audit. Full plan controls and entitlements administration remain. |
| ADMIN-06 | Pending | Managed challenge and risk administration. |
| ADMIN-05 | Partial | Operator-only invoice history and CLI payment reconciliation. Refund, invoice adjustment and automated settlement tooling remain. |
| ADMIN-07 | Partial | Restricted audit list and incident/retention docs; cases, privacy actions and reviews remain. |
| ADMIN-08–10 | Pending | Support, content editing and operator release workflows. |
| ADMIN-11 | Partial | CLI preflight and real health; integrated operations console remains. |
| ADMIN-12 | Partial | Operator audit list and protective provisioning; role management/export and integrity options remain. |
| BILL-01–05 | Partial | Configurable fixed offers, invoice snapshots, manual renewals, paid daily allowance, tenant receipts, ZarinPal settlement and signed Stripe fulfillment. Multiple tiers, automatic subscriptions, refunds and accounting exports remain. |
| BILL-06 | Pending | Enterprise quote and assisted subscription workflows. |
| DATA-01–03 | Partial | Indexed InnoDB migrations, digest-only verification state, counts, audited changes and bounded retention. Billing/analytics schemas, rollups, exports and deletion remain. |
| CMS-01 | Partial | Built WordPress plugin, real activation and six smoke-tested hooks. Full native/browser request flows, checkout and external form adapters remain. |
| CMS-02–06 | Pending | Drupal, Joomla, Magento, OpenCart and PrestaShop. |
| REL-01 | Partial | Root `downloads/`, real archives, checksums, release builders and core CI checks. Optional signing, SBOM, release CI and platform matrix remain. |
| REL-02 | Partial | Public catalog and exact manifest-bound, hashed delivery. Private entitlements, yanking and extended filters remain. |
| SEC-01 | Partial | InnoDB replay tests, strict context/scopes, middleware separation, MFA, origin controls, privacy and operator runbook. Independent review and platform hardening remain. |
| SEC-02 | Pending | Calibrated defensive evaluation, broader accessibility and capacity evidence. |
| OPS-01–05 | Partial | Bounded request and worker controls, scheduled pruning and readiness, host runbook and restore steps. Quantified capacity, alerting and richer operational profiles remain. |
| DEP-01–04 | Partial | `shield:preflight`, cPanel/DirectAdmin guide, shared-host ZIP exercised locally, and core CI definition. Live host verification, VPS profile, SMTP and deployed cron exercise remain. |
| QA-01, QA-02 | Partial | Local assertions, two-origin headless flow, package tests and private MariaDB. All pilot gates are tracked in the source specification. |
| QA-03 | Pending | Advance each feature independently with a workflow, tests and evidence. |
| QA-UNIT, QA-API, QA-REPLAY, QA-TENANT | Verified | Core targeted PHPUnit behavior and controlled concurrent solves/consumes against MariaDB. |
| QA-POLICY, QA-WIDGET, QA-FILAMENT | Partial | Fixed SMS policy, Chromium smoke and Filament scoped tests. More policies, clients, role and setting cases remain. |
| QA-BILL | Partial | Tenant boundaries, duplicate checkout and callbacks, plan snapshots, quota windows, provider failure/recovery and sandbox isolation in fixture tests. Actual merchant sandbox and live host verification remain. |
| QA-LOAD | Pending | Authorized capacity suite. |
| QA-DATA, QA-SEC | Partial | Schema, cleanup, replay, authorization and controlled download assertions. Wider hardening and suite remain. |
| QA-DOC, QA-SDK, QA-CMS | Partial | OpenAPI/Postman, real JS/PHP archive tests, WordPress/Woo activation and hook checks. Wider ecosystems and lifecycle coverage remain. |
| QA-DEPLOY, QA-A11Y | Partial | Local install and preflight, keyboard, status, RTL and expiry. Host-specific deploy and accessibility audit remain. |
