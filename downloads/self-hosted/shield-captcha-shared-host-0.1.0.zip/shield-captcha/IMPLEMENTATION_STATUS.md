# Implementation status

## 0.1.0 core checkpoint

The working application includes customer and operator Filament panels, tenant-scoped sites and credentials, a standalone checkbox proof-of-work widget, one-time backend verification, fixed-window abuse controls, SMS pre-send decisions, customer activity counts, a public English/Persian quick start and package downloads. The PHP consumer runs on a separate origin and gates its form submission on the verification API. The site playground previews the browser step using a configured sandbox key.

| Tier | State | Remaining release criteria |
| --- | --- | --- |
| P0 | Partial | Host-specific HTTPS/SMTP/cron exercise, pilot capacity and accessibility review, independently reviewed provider design, broader usage/policy UI, and remaining WordPress surface validation. |
| P1 | Partial | Adaptive/invisible and alternative providers, account/API services, configurable risk rules, feedback, alerts, billing, full panel localization and SDK expansion. |
| P2 | Pending | Fraud, scraper and agent policies, enterprise teams and branding, subscriptions and data governance. A baseline shared-host bundle is provided. |
| P3 | Pending | Optional profiles for edge, Redis, HA, SSO and calibrated risk. |

## Local evidence

- Composer resolved the PHP 8.3 platform to Laravel 13.31.0, Filament 5.7.6 and Livewire 4.4.2. Actual CLI checks used PHP 8.5.8. Live Packagist metadata requests timed out while downloading the locked upstream packages succeeded. No fresh online advisory audit was completed.
- `DB_CONNECTION=mysql DB_DATABASE=shield_test ... php vendor/bin/phpunit --no-progress` passed **19 tests and 284 assertions** against MariaDB 13.0.2 with 83 MB peak PHP memory. The two-worker race test allowed exactly one successful solve and one token consume. The suite also covered tenant isolation, audit, scoped keys, domain proof fixtures, CORS, quotas, SMS and public routes.
- One headless Chromium session verified the real cross-origin flow on Laravel and MariaDB through the PHP SDK. Missing and replayed tokens returned HTTP 422. An owned browser fixture exercised strict CSP, keyboard interaction, two independent instances, Persian directionality and expiry.
- Offline npm and Composer installed the archives. WordPress 7.1.4 and WooCommerce 11.2.1 activated the actual plugin in a separate local database. Mocked verification exercised native login, registration, reset request, comments and classic WooCommerce login and registration. Browser CMS workflows, checkout, Blocks and Store API were outside this test.
- Unpacking the shared-host ZIP yielded a working PHP application with production dependencies and published assets. Fresh MariaDB migrations, production-config preflight, Blade/config cache commands, a dump and restore of local fixture records, and the two bounded cleanup commands passed. Production mail and the actual control-panel server were outside this smoke test.
- Release artifacts, paths and digest checks are recorded in [the generated manifest](downloads/manifest.json). Catalog status remains conservative where platform testing covers only a subset. Use `node scripts/build-releases.mjs --check` to verify checksums.
- The core workflow configures PHP 8.3, MariaDB 11.4, locked dependency checks, PHPUnit and artifact integrity. It has not run remotely.

No live shared-control-panel host, production mail or payment account was used. Capacity tests and multi-browser matrices were deferred on the active workstation. [Requirements traceability](REQUIREMENTS_TRACEABILITY.md) records the full backlog with evidence and priorities.
