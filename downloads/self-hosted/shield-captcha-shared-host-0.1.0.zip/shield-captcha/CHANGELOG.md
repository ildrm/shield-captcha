# Changelog

## 0.1.0

- Laravel and Filament core with organization-scoped customer and separate operator panels.
- Browser proof of work, one-time server verification, destination-based SMS assessment and bounded retention.
- Public English/Persian docs, sandbox widget preview, PHP consumer sample, and release downloads.
