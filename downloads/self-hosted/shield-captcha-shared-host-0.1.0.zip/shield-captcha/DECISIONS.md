# Implementation decisions

| Decision | Basis |
| --- | --- |
| Laravel 13.31.0, Filament 5.7.6, Livewire 4.4.2 | Composer resolved against PHP 8.3 using local Packagist metadata when the live metadata timed out. The archives installed from locked upstream dist URLs on PHP 8.5.8. [Laravel deployment](https://laravel.com/docs/13.x/deployment), [Filament installation](https://filamentphp.com/docs/5.x/introduction/installation), [Filament package metadata](https://packagist.org/packages/filament/filament) |
| Single PHP application and two Filament panels | Tenants share an InnoDB schema. The customer panel uses organization-scoped resources and policies. The operator panel uses a dedicated guard, dedicated identity and TOTP. Customer routes use `/customer` and operator routes use `/admin`. [Filament tenancy](https://filamentphp.com/docs/5.x/users/tenancy), [Filament MFA](https://filamentphp.com/docs/5.x/users/multi-factor-authentication) |
| Standalone pilot provider | Use bounded SHA-256 work in one browser worker and state on the server. ALTCHA v2 uses a different protocol and this release does not claim compatibility. The provider needs independent review and low-end-device measurement before a commercial pilot. [ALTCHA documentation](https://altcha.org/docs/) |
| Static public assets and cron | Laravel serves Blade content, the widget is static, and Filament ships compiled assets. The host package includes dependencies and serves without Node. Cap scheduled deletes and avoid permanent processes. |
| SMS Scope | Fixed windows and a destination cooldown supply deterministic recommendations. The customer owns SMS sending and send-level idempotency. Use a tenant-controlled HMAC of the normalized destination. |
| JSON-form OpenAPI | The canonical `openapi/v1.yaml` uses JSON syntax, a YAML 1.2 subset, to support both parsers. Package archives in `downloads/` are build outputs with real checksums. |
