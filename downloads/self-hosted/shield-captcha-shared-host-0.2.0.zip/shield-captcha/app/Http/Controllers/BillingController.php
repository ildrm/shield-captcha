<?php

namespace App\Http\Controllers;

use App\Billing\BillingAccess;
use App\Billing\BillingCheckout;
use App\Billing\BillingEntitlements;
use App\Billing\BillingPlan;
use App\Billing\ZarinPalGateway;
use App\Models\BillingInvoice;
use App\Models\BillingSubscription;
use App\Models\Organization;
use App\Models\User;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Str;

class BillingController extends Controller
{
    private const PRIVATE_HEADERS = ['Cache-Control' => 'private, no-store', 'Referrer-Policy' => 'no-referrer'];

    public function __construct(
        private BillingCheckout $billing,
        private ZarinPalGateway $gateway,
    ) {}

    public function index(Request $request, Organization $organization, BillingEntitlements $entitlements): Response
    {
        $this->authorizeOrganization($request, $organization);

        return $this->render($request, 'index', [
            'organization' => $organization,
            'plan' => $this->gateway->enabled() ? BillingPlan::published() : null,
            'mode' => $this->gateway->environment(),
            'checkoutKey' => (string) Str::uuid(),
            'currentQuota' => $entitlements->dailyVerificationLimit($organization->id, 'production'),
            'paidThrough' => BillingSubscription::query()->where('organization_id', $organization->id)
                ->where('expires_at', '>', now())->latest('expires_at')->first()?->expires_at,
            'invoices' => BillingInvoice::query()->where('organization_id', $organization->id)
                ->latest()->orderByDesc('id')->simplePaginate(20),
        ]);
    }

    public function checkout(Request $request, Organization $organization): RedirectResponse
    {
        $user = $this->authorizeOrganization($request, $organization);
        $fields = $request->validate(['checkout_key' => ['required', 'uuid:4']]);
        $invoice = $this->billing->create($user, $organization, strtolower($fields['checkout_key']));
        $url = $this->gateway->checkoutUrl($invoice);

        return $url !== null ? redirect()->away($url, 303, self::PRIVATE_HEADERS) : $this->redirectToInvoice($invoice, $organization);
    }

    public function receipt(Request $request, Organization $organization, string $invoice): Response
    {
        $this->authorizeOrganization($request, $organization);
        $record = $this->findInvoice($organization, $invoice);

        return $this->render($request, 'receipt', [
            'organization' => $organization,
            'invoice' => $record,
            'isPending' => $record->status === BillingInvoice::PENDING,
            'canResume' => $this->gateway->checkoutUrl($record) !== null && BillingPlan::published() !== null,
            'canRecheck' => $record->status === BillingInvoice::PENDING && $this->gateway->matches($record),
        ]);
    }

    public function recheck(Request $request, Organization $organization, string $invoice): RedirectResponse
    {
        $this->authorizeOrganization($request, $organization);
        $record = $this->billing->reconcile($this->findInvoice($organization, $invoice));

        return $this->redirectToInvoice($record, $organization);
    }

    public function callback(Request $request, string $invoice): RedirectResponse
    {
        abort_unless($request->isMethod('GET'), 405);
        $authority = $request->query('Authority');
        $status = $request->query('Status');
        abort_unless(is_string($authority) && strlen($authority) === 36 && in_array($status, ['OK', 'NOK'], true), 404);

        $record = BillingInvoice::query()->findOrFail($invoice);
        abort_unless($record->authority !== null && hash_equals($record->authority, $authority), 404);

        if ($status === 'OK') {
            $this->billing->reconcile($record);
        }

        return redirect()->route('billing.return', ['invoice' => $invoice], 303, self::PRIVATE_HEADERS);
    }

    public function returnToCustomer(Request $request, string $invoice): Response|RedirectResponse
    {
        $user = $request->user('web');
        if ($user instanceof User) {
            $record = BillingInvoice::query()->with('organization')->find($invoice);
            if ($record !== null && BillingAccess::canManage($user, $record->organization)) {
                return $this->redirectToInvoice($record, $record->organization);
            }
        }

        return $this->render($request, 'return');
    }

    private function authorizeOrganization(Request $request, Organization $organization): User
    {
        $user = $request->user('web');
        abort_unless($user instanceof User && BillingAccess::canManage($user, $organization), 403);

        return $user;
    }

    private function findInvoice(Organization $organization, string $invoice): BillingInvoice
    {
        return BillingInvoice::query()->where('organization_id', $organization->id)->findOrFail($invoice);
    }

    private function redirectToInvoice(BillingInvoice $invoice, Organization $organization): RedirectResponse
    {
        return redirect()->route('billing.receipt', ['organization' => $organization->slug, 'invoice' => $invoice->id], 303, self::PRIVATE_HEADERS);
    }

    private function render(Request $request, string $view, array $data = []): Response
    {
        $locale = $request->session()->get('locale');
        app()->setLocale(in_array($locale, ['en', 'fa'], true) ? $locale : 'en');

        return response()->view('billing.'.$view, $data, 200, self::PRIVATE_HEADERS);
    }
}
