<?php

namespace App\Sms;

use App\Models\Site;
use App\Models\SmsDelivery;
use App\Shield\ApiProblem;
use App\Shield\Captcha;
use Closure;
use Illuminate\Contracts\Encryption\DecryptException;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use SensitiveParameter;

final class DeliverSms
{
    public const IRAN_MOBILE = '/\A(?:0|\+98|0098)(9[0-9]{9})\z/';

    public function __construct(private readonly Captcha $captcha, private readonly Kavenegar $provider) {}

    public function send(
        #[SensitiveParameter] string $secret,
        string $key,
        string $action,
        string $eventId,
        #[SensitiveParameter] string $destination,
        #[SensitiveParameter] string $otp,
    ): array {
        if (! config('sms.kavenegar.enabled')) {
            throw new ApiProblem('sms_delivery_disabled', 503);
        }
        if (! preg_match(self::IRAN_MOBILE, $destination, $matches)) {
            throw new ApiProblem('invalid_request', 422);
        }

        $destination = '0'.$matches[1];
        [$delivery, $providerSettings] = $this->captcha->assessSmsForDelivery(
            $secret,
            $key,
            $action,
            fn (Site $site, Closure $assess): array|ApiProblem => $this->claim($site, $action, $eventId, $destination, $otp, $assess),
        );

        if ($providerSettings !== null) {
            // The dispatch claim is committed before calling the carrier. An exception or timeout never reopens it.
            $result = $this->provider->send($providerSettings['api_key'], $providerSettings['template'], $destination, $otp);
            $delivery->update($result);
        }

        return $this->outcome($delivery);
    }

    private function claim(
        Site $site,
        string $action,
        string $eventId,
        #[SensitiveParameter] string $destination,
        #[SensitiveParameter] string $otp,
        Closure $assess,
    ): array|ApiProblem {
        $encryptedKey = DB::table(KavenegarSettings::DIGEST_KEY_TABLE)->where('organization_id', $site->organization_id)->value('digest_key');

        if (! is_string($encryptedKey)) {
            throw new ApiProblem('sms_provider_unavailable', 503);
        }

        $digestKey = $this->decrypt($encryptedKey);
        $eventContext = $site->id.':'.$eventId;
        $eventDigest = hash_hmac('sha256', 'shield:sms:delivery:v1:'.$eventContext, $digestKey);
        $requestDigest = hash_hmac('sha256', 'shield:sms:body:v1:'.$action.':'.$destination.':'.$otp, $digestKey);
        $existing = SmsDelivery::query()->where('site_id', $site->id)->where('event_digest', $eventDigest)->first();

        if ($existing !== null) {
            if (! hash_equals($existing->request_digest, $requestDigest)) {
                throw new ApiProblem('idempotency_conflict', 409);
            }

            return [$existing, null];
        }

        $settings = DB::table(KavenegarSettings::SETTINGS_TABLE)->where('site_id', $site->id)->first();
        if ($settings === null || ! KavenegarSettings::templateAllowed($settings->template)) {
            throw new ApiProblem('sms_provider_unavailable', 503);
        }
        if ($settings->action !== $action) {
            throw new ApiProblem('context_mismatch', 403);
        }

        $apiKey = $this->decrypt($settings->api_key);
        $assessment = $assess(
            hash_hmac('sha256', 'shield:sms:assessment:v1:'.$eventContext, $digestKey),
            hash_hmac('sha256', 'shield:sms:destination:v1:'.$destination, $digestKey),
        );
        if ($assessment instanceof ApiProblem) {
            return $assessment;
        }
        if ($assessment['decision'] !== 'allow') {
            return new ApiProblem('sms_throttled', 429, $assessment['retry_after'] ?? null);
        }

        $delivery = SmsDelivery::query()->create([
            'site_id' => $site->id,
            'action' => $action,
            'assessment_id' => $assessment['assessment_id'],
            'event_digest' => $eventDigest,
            'request_digest' => $requestDigest,
            'state' => SmsDelivery::DISPATCHING,
        ]);

        return [$delivery, ['api_key' => $apiKey, 'template' => $settings->template]];
    }

    private function decrypt(#[SensitiveParameter] string $value): string
    {
        try {
            return Crypt::decryptString($value);
        } catch (DecryptException) {
            throw new ApiProblem('sms_provider_unavailable', 503);
        }
    }

    private function outcome(SmsDelivery $delivery): array
    {
        if ($delivery->state === SmsDelivery::ACCEPTED) {
            return [
                'success' => true,
                'state' => SmsDelivery::ACCEPTED,
                'delivery_id' => $delivery->id,
                'provider_reference' => $delivery->provider_reference,
            ];
        }

        if ($delivery->state === SmsDelivery::REJECTED) {
            throw new ApiProblem('sms_provider_rejected', 502);
        }

        if ($delivery->state === SmsDelivery::DISPATCHING
            && $delivery->created_at->isAfter(now()->subSeconds(SmsDelivery::DISPATCH_TIMEOUT_SECONDS))) {
            throw new ApiProblem('sms_dispatch_in_progress', 409);
        }

        throw new ApiProblem('sms_delivery_unknown', 409);
    }
}
