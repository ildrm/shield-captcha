<?php

namespace App\Sms;

use App\Models\Organization;
use App\Models\Site;
use App\Models\SiteCredential;
use App\Shield\SiteKeys;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;
use SensitiveParameter;

final class KavenegarSettings
{
    public const SETTINGS_TABLE = 'shield_sms_kavenegar_sites';

    public const DIGEST_KEY_TABLE = 'shield_sms_tenant_keys';

    public function __construct(private readonly SiteKeys $keys) {}

    public function configure(Site $site, string $action, string $template, #[SensitiveParameter] string $apiKey): string
    {
        if (! self::templateAllowed($template) || ! preg_match('/\A[A-Za-z0-9_-]{16,256}\z/', $apiKey)) {
            throw ValidationException::withMessages(['provider' => 'Use an allowed template and a valid Kavenegar API key.']);
        }

        return DB::transaction(function () use ($site, $action, $template, $apiKey): string {
            [$organization, $site] = $this->lockSite($site);

            if (! $organization->is_active || ! $site->is_active || $site->environment !== 'production'
                || $site->domain_verified_at === null || ! in_array($action, $site->actions, true)) {
                throw ValidationException::withMessages(['site' => 'Use an active, DNS-verified production site and registered action.']);
            }

            $this->revokeCredentials($site);
            if (! DB::table(self::DIGEST_KEY_TABLE)->where('organization_id', $organization->id)->exists()) {
                DB::table(self::DIGEST_KEY_TABLE)->insert([
                    'organization_id' => $organization->id,
                    'digest_key' => Crypt::encryptString(bin2hex(random_bytes(32))),
                ]);
            }

            DB::table(self::SETTINGS_TABLE)->upsert([[
                'site_id' => $site->id,
                'action' => $action,
                'template' => $template,
                'api_key' => Crypt::encryptString($apiKey),
                'created_at' => now(),
                'updated_at' => now(),
            ]], ['site_id'], ['action', 'template', 'api_key', 'updated_at']);

            return $this->keys->issue($site, 'sms_send');
        }, 3);
    }

    public function disable(Site $site): void
    {
        DB::transaction(function () use ($site): void {
            [, $site] = $this->lockSite($site);

            $this->revokeCredentials($site);
            DB::table(self::SETTINGS_TABLE)->where('site_id', $site->id)->delete();
        }, 3);
    }

    public static function templateAllowed(string $template): bool
    {
        return preg_match('/\A[a-zA-Z0-9][a-zA-Z0-9-]{0,63}\z/', $template) === 1
            && in_array($template, config('sms.kavenegar.templates'), true);
    }

    /** @return array{Organization, Site} */
    private function lockSite(Site $site): array
    {
        $organization = Organization::query()->lockForUpdate()->findOrFail($site->organization_id);
        $site = Site::query()->where('organization_id', $organization->id)->lockForUpdate()->findOrFail($site->id);

        return [$organization, $site];
    }

    private function revokeCredentials(Site $site): void
    {
        SiteCredential::query()->where('site_id', $site->id)->where('scope', 'sms_send')
            ->whereNull('revoked_at')->update(['revoked_at' => now()]);
    }
}
