<?php

namespace App\Billing;

use App\Models\BillingInvoice;
use App\Models\BillingSubscription;
use App\Models\Organization;
use App\Models\User;
use Illuminate\Database\UniqueConstraintViolationException;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

final class BillingCheckout
{
    public function __construct(private ZarinPalGateway $gateway) {}

    public function create(User $user, Organization $organization, string $key): BillingInvoice
    {
        $plan = BillingPlan::published();
        abort_unless($plan !== null && $this->gateway->enabled(), 503, 'Checkout is unavailable.');

        [$invoice, $created] = DB::transaction(function () use ($user, $organization, $key, $plan): array {
            $organization = Organization::query()->lockForUpdate()->findOrFail($organization->id);
            abort_unless(BillingAccess::canManage($user, $organization), 403);

            $invoice = BillingInvoice::query()->where('organization_id', $organization->id)
                ->where('checkout_key', $key)->lockForUpdate()->first();
            if ($invoice !== null) {
                if ($invoice->status === BillingInvoice::CREATING && $invoice->created_at->lte(now()->subMinute())) {
                    $invoice->forceFill(['status' => BillingInvoice::CREATION_FAILED])->save();
                }

                return [$invoice, false];
            }

            return [BillingInvoice::query()->create([
                'id' => (string) Str::uuid(),
                'organization_id' => $organization->id,
                'created_by' => $user->id,
                'checkout_key' => $key,
                'environment' => $this->gateway->environment(),
                'merchant_fingerprint' => $this->gateway->fingerprint(),
                'amount_irr' => $plan->amountIrr,
                'term_days' => $plan->termDays,
                'daily_verifications' => $plan->dailyVerifications,
                'status' => BillingInvoice::CREATING,
            ]), true];
        }, 3);

        if (! $created) {
            return $invoice;
        }

        $authority = $this->gateway->request($invoice);
        try {
            BillingInvoice::query()->whereKey($invoice->id)->where('status', BillingInvoice::CREATING)->update([
                'authority' => $authority,
                'status' => $authority !== null ? BillingInvoice::PENDING : BillingInvoice::CREATION_FAILED,
            ]);
        } catch (UniqueConstraintViolationException) {
            BillingInvoice::query()->whereKey($invoice->id)->where('status', BillingInvoice::CREATING)
                ->update(['status' => BillingInvoice::CREATION_FAILED]);
        }

        return $invoice->refresh();
    }

    public function reconcile(BillingInvoice $invoice): BillingInvoice
    {
        $claimed = $this->claimVerification($invoice);
        if ($claimed === null) {
            return $invoice->refresh();
        }

        $verification = $this->gateway->verify($claimed);
        if ($verification !== null) {
            try {
                $this->settle($claimed, $verification);
            } catch (UniqueConstraintViolationException) {
                Log::warning('Billing verification requires reconciliation', ['invoice_id' => $invoice->id]);
            }
        }

        return $invoice->refresh();
    }

    private function claimVerification(BillingInvoice $invoice): ?BillingInvoice
    {
        return DB::transaction(function () use ($invoice): ?BillingInvoice {
            Organization::query()->lockForUpdate()->findOrFail($invoice->organization_id);
            $invoice = BillingInvoice::query()->lockForUpdate()->findOrFail($invoice->id);
            $now = now();
            if ($invoice->status !== BillingInvoice::PENDING || $invoice->authority === null
                || ! $this->gateway->matches($invoice) || $invoice->next_verify_at?->gt($now)) {
                return null;
            }

            $invoice->forceFill(['next_verify_at' => $now->addSeconds(20)])->save();

            return $invoice;
        }, 3);
    }

    private function settle(BillingInvoice $invoice, PaymentVerification $verification): void
    {
        DB::transaction(function () use ($invoice, $verification): void {
            Organization::query()->lockForUpdate()->findOrFail($invoice->organization_id);
            $locked = BillingInvoice::query()->lockForUpdate()->findOrFail($invoice->id);
            if ($locked->status !== BillingInvoice::PENDING) {
                return;
            }

            $now = now()->toImmutable();
            $locked->forceFill([
                'paid_at' => $now,
                'status' => BillingInvoice::PAID,
                'provider_reference' => $verification->reference,
                'verified_code' => $verification->code,
                'next_verify_at' => null,
            ])->save();

            if ($locked->environment === 'production') {
                $lastTerm = BillingSubscription::query()->where('organization_id', $locked->organization_id)
                    ->where('expires_at', '>', $now)->latest('expires_at')->first();
                $startsAt = $lastTerm?->expires_at ?? $now;

                BillingSubscription::query()->create([
                    'invoice_id' => $locked->id,
                    'organization_id' => $locked->organization_id,
                    'starts_at' => $startsAt,
                    'expires_at' => $startsAt->addDays($locked->term_days),
                    'daily_verifications' => $locked->daily_verifications,
                ]);
            }
        }, 3);
    }
}
