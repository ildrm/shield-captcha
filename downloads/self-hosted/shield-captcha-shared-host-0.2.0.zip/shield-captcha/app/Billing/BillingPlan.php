<?php

namespace App\Billing;

final readonly class BillingPlan
{
    private function __construct(
        public int $amountIrr,
        public int $termDays,
        public int $dailyVerifications,
    ) {}

    public static function published(): ?self
    {
        $amount = self::integer('amount_irr', 1, 1_000_000_000);
        $term = self::integer('term_days', 1, 365);
        $limit = self::integer('daily_verifications', BillingEntitlements::FREE_DAILY_LIMIT + 1, 2_147_483_647);

        return $amount !== false && $term !== false && $limit !== false
            ? new self($amount, $term, $limit)
            : null;
    }

    private static function integer(string $key, int $min, int $max): int|false
    {
        return filter_var(config('billing.plan.'.$key), FILTER_VALIDATE_INT, [
            'options' => ['min_range' => $min, 'max_range' => $max],
        ]);
    }
}
