<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasOne;

class BillingInvoice extends Model
{
    public const CREATING = 'creating';

    public const PENDING = 'pending';

    public const CREATION_FAILED = 'creation_failed';

    public const PAID = 'paid';

    protected $keyType = 'string';

    public $incrementing = false;

    protected $fillable = [
        'id', 'organization_id', 'created_by', 'checkout_key', 'environment', 'merchant_fingerprint',
        'amount_irr', 'term_days', 'daily_verifications', 'status',
    ];

    protected $hidden = ['authority', 'merchant_fingerprint', 'checkout_key'];

    protected function casts(): array
    {
        return [
            'amount_irr' => 'integer',
            'term_days' => 'integer',
            'daily_verifications' => 'integer',
            'verified_code' => 'integer',
            'paid_at' => 'immutable_datetime',
            'next_verify_at' => 'immutable_datetime',
        ];
    }

    public function organization(): BelongsTo
    {
        return $this->belongsTo(Organization::class);
    }

    public function subscription(): HasOne
    {
        return $this->hasOne(BillingSubscription::class, 'invoice_id');
    }
}
