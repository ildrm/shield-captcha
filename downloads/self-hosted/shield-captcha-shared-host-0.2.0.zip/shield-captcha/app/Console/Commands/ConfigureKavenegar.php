<?php

namespace App\Console\Commands;

use App\Models\Site;
use App\Sms\KavenegarSettings;
use Illuminate\Console\Command;
use Illuminate\Validation\ValidationException;

final class ConfigureKavenegar extends Command
{
    protected $signature = 'shield:sms:kavenegar {site : Public site key} {action? : Registered OTP action} {template? : Approved Kavenegar template} {--disable : Remove the credential and revoke send keys}';

    protected $description = 'Provision or disable Kavenegar OTP delivery for a production site';

    public function handle(KavenegarSettings $settings): int
    {
        $site = Site::query()->where('public_key', $this->argument('site'))->first();
        if ($site === null) {
            $this->error('Site not found.');

            return self::FAILURE;
        }

        if ($this->option('disable')) {
            $settings->disable($site);
            $this->info('Kavenegar delivery disabled and send credentials revoked for this site.');

            return self::SUCCESS;
        }

        $action = $this->argument('action');
        $template = $this->argument('template');
        if (! $this->input->isInteractive() || ! is_string($action) || ! is_string($template)) {
            $this->error('Run this command in an interactive terminal with a site, action, and approved template.');

            return self::FAILURE;
        }

        $apiKey = $this->secret('Kavenegar API key', false);
        if (! is_string($apiKey)) {
            return self::FAILURE;
        }

        try {
            $secret = $settings->configure($site, $action, $template, $apiKey);
        } catch (ValidationException $exception) {
            $this->error($exception->getMessage());

            return self::FAILURE;
        }

        $this->info('Save this SMS send key in the customer backend. It is shown once.');
        $this->line($secret);

        return self::SUCCESS;
    }
}
