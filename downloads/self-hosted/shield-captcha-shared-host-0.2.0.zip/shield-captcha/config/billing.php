<?php

return [
    'zarinpal' => [
        'enabled' => env('BILLING_ZARINPAL_ENABLED', false),
        'environment' => env('BILLING_ZARINPAL_ENVIRONMENT', 'sandbox'),
        'merchant_id' => env('BILLING_ZARINPAL_MERCHANT_ID'),
    ],
    'plan' => [
        'amount_irr' => env('BILLING_PLAN_AMOUNT_IRR'),
        'term_days' => env('BILLING_PLAN_TERM_DAYS', 30),
        'daily_verifications' => env('BILLING_PLAN_DAILY_VERIFICATIONS', 50000),
    ],
];
